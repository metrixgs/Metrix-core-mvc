<?php

namespace App\Controllers;

class MapaController extends BaseController
{
    public function index()
    {
        return view('mapa');
    }
}

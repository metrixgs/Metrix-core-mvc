<h1>Acceso no autorizado</h1>
<p>No tienes permisos para acceder a esta sección.</p>
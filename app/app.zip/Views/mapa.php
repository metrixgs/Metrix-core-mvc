<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mapa</title>
    <script type="module" crossorigin src="<?= base_url('vite_project/assets/index.js'); ?>"></script>
    <link rel="stylesheet" href="<?= base_url('vite_project/assets/index.css'); ?>">
</head>
<body>
    <div id="app"></div>
</body>
</html>
